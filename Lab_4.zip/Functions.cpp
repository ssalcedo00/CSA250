/*
Kim, Ji Soo
Nguyen, Tony
Phan, Thang
Salcedo, Salvador

CS A250
September 22, 2018

Lab 3
*/

#include "AnyList.h"

// Definition of function deleteNode
void AnyList::deleteNode(int deleteData)
{
	// Write your code here...
	if (!count) 
		cerr << "Cannot delete from an empty list." << endl;
	else
	{
		Node *current = ptrToFirst;
		bool found = false;

		// If the item is the first one to be deleted
		if (current->getData() == deleteData)
		{
			ptrToFirst = ptrToFirst->getPtrToNext();
			delete current;
			current = nullptr;
			count--;
			found = true;
		}

		// If the item to be deleted is somewhere in the middle or last
		else
		{
			Node *trailCurrent = current;
			current = current->getPtrToNext();

			while (current != nullptr)
			{
				if (current->getData() == deleteData)
				{
					trailCurrent->setPtrToNext(current->getPtrToNext());
					delete current;
					current = nullptr;
					trailCurrent = nullptr;
					count--;
					found = true;
				}
				else
				{
					trailCurrent = current;
					current = current->getPtrToNext();
				}
			}

			// The item was not found at all
			if(!found)
			cerr << "The item to delete is not in the list." << endl;
		}
	}
}